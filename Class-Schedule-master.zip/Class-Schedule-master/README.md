## Class-Schedule
Android app for showing the class schedules. The students of the class can also be notified by the class representative if there is any updated news regarding the class.

**In backend firebase datase is used**

## Installation
install android version 2.2 or higher then import this project
